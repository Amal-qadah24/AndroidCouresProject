package com.example.androidcouresproject;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;



import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;



import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class AddStudentActivity extends AppCompatActivity {

    EditText etName, etID;
    Spinner spMajor;
    Button btnAddStudent;
    RequestQueue queue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_student);

        etName = findViewById(R.id.etName);
        etID = findViewById(R.id.etID);
        spMajor = findViewById(R.id.spMajor);
        btnAddStudent = findViewById(R.id.btnAddStudent);

        queue = Volley.newRequestQueue(this);

        // إعداد التخصصات
        String[] majors = {"Computer Science", "IT", "Engineering", "Business"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, majors);
        spMajor.setAdapter(adapter);

        btnAddStudent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = etName.getText().toString();
                String id = etID.getText().toString();
                String major = spMajor.getSelectedItem().toString();

                if (name.isEmpty() || id.isEmpty()) {
                    Toast.makeText(AddStudentActivity.this, "Fill all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                sendStudentToServer(name, id, major);
            }
        });
    }

    private void sendStudentToServer(String name, String id, String major) {
        String url = "http://YOUR_SERVER_URL/add_student.php"; // عدّل الرابط حسب سيرفرك

        StringRequest request = new StringRequest(Request.Method.POST, url,
                response -> Toast.makeText(AddStudentActivity.this, response, Toast.LENGTH_LONG).show(),
                error -> Toast.makeText(AddStudentActivity.this, "Error: " + error.getMessage(), Toast.LENGTH_LONG).show()
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("name", name);
                params.put("id", id);
                params.put("major", major);
                return params;
            }
        };

        queue.add(request);
    }
}
