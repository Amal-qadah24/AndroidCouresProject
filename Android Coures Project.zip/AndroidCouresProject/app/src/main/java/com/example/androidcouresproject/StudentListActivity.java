package com.example.androidcouresproject;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class StudentListActivity extends AppCompatActivity {

    private RequestQueue queue;
    private ListView lstStudents;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_list);

        lstStudents = findViewById(R.id.lstStudents);
        queue = Volley.newRequestQueue(this);

        loadStudents();
    }

    private void loadStudents() {
        String url = "http://YOUR_SERVER/get_students.php";

        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url,
                null, response -> {
            ArrayList<String> list = new ArrayList<>();
            for (int i = 0; i < response.length(); i++) {
                try {
                    JSONObject obj = response.getJSONObject(i);
                    String line = obj.getString("name") + " | " +
                            obj.getString("student_id") + " | " +
                            obj.getString("major");
                    list.add(line);
                } catch (JSONException e) {
                    Log.d("json_error", e.toString());
                }
            }
            ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                    android.R.layout.simple_list_item_1, list);
            lstStudents.setAdapter(adapter);
        }, error -> Log.d("volley_error", error.toString()));

        queue.add(request);
    }
}
